import Utilities.compiler as uc
import fnmatch
import os
from zipfile import PyZipFile, ZIP_STORED
import shutil
import io
from Utilities.unpyc3 import decompile
import fnmatch
import os
pycfolder = ""

def decompile_dir(rootPath):
    pattern = '*.pyc'
    for root, dirs, files in os.walk(rootPath):
        for filename in fnmatch.filter(files, pattern):
            p = str(os.path.join(root, filename))
            try:
                py = decompile(p)
                with io.open(p.replace('.pyc', '.py'), 'w', encoding='utf-8') as output_py:
                    for statement in py.statements:
                        output_py.write(str(statement) + '\r')
                print(p)
            except Exception as ex:
                print("FAILED to decompile %s" % p)

def inputbaby():
    print('MONACA SCRIPTDECOMPILER BY MONACA')
    print('')
    print("|Bad boy(´・ω・｀)|")
    print('_________________________________________________________________________________')
    print('WINOWS:Exit to push *ctr _shift _c')
    print('-----------------------------Settings Mod dir')
    pycfolder = input()
    print('---------------------Decompiling...')
    decompile_dir(pycfolder)
    print('GOOD LUCK--------------------------------------------')
    inputbaby()
inputbaby()

script_package_types = ['*.zip', '*.ts4script']
